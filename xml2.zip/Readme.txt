# Introduction

This is a demo for the XML pharse using PHP. CSS is used to make the output as a tree. To simple the problems, only some basic information is included, but it is easy to expand.

# How to use it?

To use it, what you need to do is to upload it to the server running PHP. What's more, remember to allow the file 'persons.xml' has the read and write permission.

# Features

- A good presentation for connection of different people.
- Search people arrcording to last name.
- Basic consistency test of the data
- Save data in 'persons.xml'
